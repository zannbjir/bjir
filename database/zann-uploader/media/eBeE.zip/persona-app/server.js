const express    = require('express');
const session    = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);
const bcrypt     = require('bcryptjs');
const multer     = require('multer');
const Database   = require('better-sqlite3');
const path       = require('path');
const fs         = require('fs');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── INIT DIRS ────────────────────────────────────────────────────────────────
['./uploads', './public'].forEach(d => { if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true }); });

// ── DATABASE ─────────────────────────────────────────────────────────────────
const db = new Database('./data.db');
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT UNIQUE NOT NULL,
    password      TEXT NOT NULL,
    display_name  TEXT DEFAULT '',
    title         TEXT DEFAULT '',
    tagline       TEXT DEFAULT '',
    about         TEXT DEFAULT '',
    profile_photo TEXT DEFAULT '',
    banner        TEXT DEFAULT '',
    songs         TEXT DEFAULT '[]',
    skills        TEXT DEFAULT '[]',
    experience    TEXT DEFAULT '[]',
    contacts      TEXT DEFAULT '{}',
    streams       TEXT DEFAULT '[]',
    created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
  )
`);

// ── MIDDLEWARE ────────────────────────────────────────────────────────────────
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
  store: new SQLiteStore({ db: 'sessions.db', dir: '.' }),
  secret: process.env.SESSION_SECRET || 'personaspace-dev-secret-change-in-prod',
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax'
  }
}));

// ── FILE UPLOAD ───────────────────────────────────────────────────────────────
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, './uploads'),
  filename:    (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${req.session.userId}_${Date.now()}${ext}`);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 20 * 1024 * 1024 }, // 20 MB
  fileFilter: (req, file, cb) => {
    const ok = /\.(jpg|jpeg|png|gif|webp)$/i.test(file.originalname);
    cb(ok ? null : new Error('Only images/GIFs allowed'), ok);
  }
});

// ── HELPERS ───────────────────────────────────────────────────────────────────
const parseUser = user => {
  const { password, ...safe } = user;
  safe.songs      = JSON.parse(safe.songs      || '[]');
  safe.skills     = JSON.parse(safe.skills     || '[]');
  safe.experience = JSON.parse(safe.experience || '[]');
  safe.contacts   = JSON.parse(safe.contacts   || '{}');
  safe.streams    = JSON.parse(safe.streams    || '[]');
  return safe;
};

const requireAuth = (req, res, next) => {
  if (!req.session?.userId) return res.status(401).json({ error: 'Unauthorized' });
  next();
};

// ── AUTH ROUTES ───────────────────────────────────────────────────────────────
app.get('/api/session', (req, res) => {
  res.json(req.session?.userId
    ? { loggedIn: true,  username: req.session.username, userId: req.session.userId }
    : { loggedIn: false }
  );
});

app.post('/api/register', async (req, res) => {
  try {
    const { username = '', password = '', display_name = '' } = req.body;
    const u = username.trim().toLowerCase();

    if (!u || !password)          return res.status(400).json({ error: 'Username dan password wajib diisi' });
    if (u.length < 3)             return res.status(400).json({ error: 'Username minimal 3 karakter' });
    if (password.length < 6)     return res.status(400).json({ error: 'Password minimal 6 karakter' });
    if (!/^[a-z0-9_]+$/.test(u)) return res.status(400).json({ error: 'Username hanya boleh huruf, angka, dan underscore' });

    const hash   = await bcrypt.hash(password, 12);
    const result = db.prepare(
      'INSERT INTO users (username, password, display_name) VALUES (?, ?, ?)'
    ).run(u, hash, display_name.trim() || username);

    req.session.userId   = result.lastInsertRowid;
    req.session.username = u;
    res.json({ success: true, username: u });
  } catch (err) {
    if (err.message.includes('UNIQUE')) return res.status(409).json({ error: 'Username sudah digunakan' });
    console.error(err);
    res.status(500).json({ error: 'Terjadi kesalahan server' });
  }
});

app.post('/api/login', async (req, res) => {
  try {
    const { username = '', password = '' } = req.body;
    const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username.trim().toLowerCase());
    if (!user) return res.status(401).json({ error: 'Username atau password salah' });

    const valid = await bcrypt.compare(password, user.password);
    if (!valid) return res.status(401).json({ error: 'Username atau password salah' });

    req.session.userId   = user.id;
    req.session.username = user.username;
    res.json({ success: true, username: user.username });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Terjadi kesalahan server' });
  }
});

app.post('/api/logout', (req, res) => {
  req.session.destroy(() => {
    res.clearCookie('connect.sid');
    res.json({ success: true });
  });
});

// ── PROFILE ROUTES ────────────────────────────────────────────────────────────
app.get('/api/me', requireAuth, (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.session.userId);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json(parseUser(user));
});

app.put('/api/profile', requireAuth, (req, res) => {
  try {
    const { display_name, title, tagline, about, songs, skills, experience, contacts, streams } = req.body;
    db.prepare(`
      UPDATE users SET
        display_name=?, title=?, tagline=?, about=?,
        songs=?, skills=?, experience=?, contacts=?, streams=?
      WHERE id=?
    `).run(
      display_name || '', title || '', tagline || '', about || '',
      JSON.stringify(songs      || []),
      JSON.stringify(skills     || []),
      JSON.stringify(experience || []),
      JSON.stringify(contacts   || {}),
      JSON.stringify(streams    || []),
      req.session.userId
    );
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Gagal menyimpan profil' });
  }
});

app.post('/api/upload/photo', requireAuth, upload.single('photo'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  const url = `/uploads/${req.file.filename}`;
  db.prepare('UPDATE users SET profile_photo=? WHERE id=?').run(url, req.session.userId);
  res.json({ url });
});

app.post('/api/upload/banner', requireAuth, upload.single('banner'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  const url = `/uploads/${req.file.filename}`;
  db.prepare('UPDATE users SET banner=? WHERE id=?').run(url, req.session.userId);
  res.json({ url });
});

// Public profile (read-only)
app.get('/api/user/:username', (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE username = ?').get(req.params.username);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json(parseUser(user));
});

// ── START ─────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🚀  PersonaSpace running → http://localhost:${PORT}\n`);
});
