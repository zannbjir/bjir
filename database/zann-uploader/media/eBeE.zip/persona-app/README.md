# PersonaSpace 🌌

Platform profile pribadi multi-user dengan music streaming dashboard.

## Stack
- **Backend**: Node.js + Express
- **Database**: SQLite (via better-sqlite3)
- **Auth**: express-session + bcryptjs
- **Upload**: multer (foto profil & banner GIF)
- **Frontend**: Vanilla HTML/CSS/JS

---

## Cara Menjalankan (Lokal)

```bash
# 1. Install dependencies
npm install

# 2. Jalankan server
npm start
# atau untuk development dengan auto-reload:
npm run dev

# 3. Buka browser
open http://localhost:3000
```

---

## Deploy ke Hosting

### Railway (Gratis / Mudah)
1. Push project ini ke GitHub
2. Buka [railway.app](https://railway.app) → New Project → Deploy from GitHub
3. Set environment variable:
   ```
   SESSION_SECRET=isi-dengan-string-random-panjang
   NODE_ENV=production
   ```
4. Railway otomatis beri domain publik ✅

### Render.com
1. Push ke GitHub
2. New Web Service → connect repo
3. Build Command: `npm install`
4. Start Command: `node server.js`
5. Add env vars: `SESSION_SECRET`, `NODE_ENV=production`

### VPS (DigitalOcean / Linode)
```bash
# Di server
git clone <your-repo>
cd personaspace
npm install
# Install PM2
npm install -g pm2
SESSION_SECRET=your-secret pm2 start server.js --name personaspace
pm2 save && pm2 startup
```
Pasang Nginx sebagai reverse proxy ke port 3000.

---

## Fitur
- ✅ Register & Login multi-user
- ✅ Session persisten (7 hari)
- ✅ Upload foto profil & banner GIF (tersimpan di server)
- ✅ Edit profil inline (nama, jabatan, about, dll)
- ✅ Tambah/hapus kelebihan (skill cards)
- ✅ Timeline pengalaman
- ✅ Music player dengan playlist persisten
- ✅ Embed Spotify / YouTube / SoundCloud di beranda
- ✅ Auto-save perubahan ke database

## Struktur File
```
├── server.js          ← Backend Express
├── package.json
├── data.db            ← Auto-dibuat saat pertama run
├── sessions.db        ← Auto-dibuat
├── uploads/           ← Foto & banner user (auto-dibuat)
└── public/
    ├── index.html     ← Halaman Login / Register
    ├── home.html      ← Beranda + Music Streaming
    └── profile.html   ← Edit Profil Lengkap
```

## Env Variables
| Variabel | Default | Keterangan |
|---|---|---|
| `PORT` | 3000 | Port server |
| `SESSION_SECRET` | dev-secret | **Wajib ganti** di production! |
| `NODE_ENV` | development | Set `production` saat hosting |
